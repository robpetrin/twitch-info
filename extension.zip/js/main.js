// $(document).ready(function(){
//     var gameList = [
//         'Jackbox Party Pack 3',
//         'Jackbox Party Pack 4',
//         'Jackbox Party Pack 5',
//         'Jackbox Party Pack 6',
//         'Duck Game',
//         'Rocket League',
//         'Halo: Master Chief Collection',
//         'Wrestling Revolution 3D',
//         'Tablestop Simulator',
//         'Retro Games'
//     ]

//     function Hello() {
//         console.log('work');
//     }

//     Hello();

// });